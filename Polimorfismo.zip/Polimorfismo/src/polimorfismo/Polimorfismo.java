/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polimorfismo;

/**
 *
 * @author Arthusr56
 */
import java.util.Scanner;
import java.util.ArrayList;

public class Polimorfismo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        
        ArrayList<Automovil> ListaVehi = new ArrayList<Automovil>(10);
        Automovil Auxiliar = new Automovil();
        String Marca,Modelo,Precio,Color;
        int gas;
        
        for(int i = 0 ; i < 10 ; i++){
            System.out.println("Ingrese la marca del vehiculo " + i + ":"); 
            Marca = input.nextLine();
            System.out.println("Ingrese el modelo del vehiculo " + i + ":"); 
            Modelo = input.nextLine(); 
            System.out.println("Ingrese el precio del vehiculo " + i + ":"); 
            Precio = input.nextLine();            
            System.out.println("Ingrese el color del vehiculo " + i + ":"); 
            Color = input.nextLine();
            System.out.println("Ingrese la gasolina contenida en el vehiculo " + i + ":");
            gas = input.nextInt();
            
            Auxiliar.setMarca(Marca);
            Auxiliar.setModelo(Modelo);
            Auxiliar.setPrecio(Precio);
            Auxiliar.setColor(Color);
            Auxiliar.setGasolina(gas);
            
             ListaVehi.set(i, Auxiliar);
        }
        
        boolean Ciclo = true,Vehieje,Activo;
        int Opcion,Accion;
        String Giro;
        
        while(Ciclo == true){
            System.out.println("Ingrese el numero de la opcion que quiere seleccionar");
            System.out.println("1) Usar vehiculo");
            System.out.println("2) Salir");
             Opcion = input.nextInt();
                     
             if(Opcion == 1){
                 System.out.println("Que vehiculo quiere utilizar? Ingrese el indice del vehiculo");
                  Opcion = input.nextInt();
                  Activo = false;
                  Vehieje = true;
                  Auxiliar = ListaVehi.get(Opcion);
                
                while(Vehieje = true){  
                 System.out.println("Elija la accion que quiere ejecutar");
                 System.out.println("1) Encender");
                 System.out.println("2) Apagar");
                 System.out.println("3) Avanzar");
                 System.out.println("4) Girar");
                 System.out.println("5) Salir");
                  Accion = input.nextInt();
                    
                   switch(Accion){
                       case 1:
                         if(Activo == true){
                             System.out.println("El vehiculo ya esta encendido");   
                         } 
                         else{
                             System.out.println(Auxiliar.Encender(Auxiliar.getGasolina())); 
                            if(Auxiliar.getGasolina() > 0)Activo = true; 
                         }
                       
                       case 2:
                         if(Activo == false){
                             System.out.println("El vehiculo ya esta apagado");
                         }  
                         else{
                             System.out.println(Auxiliar.Apagar());
                             Activo = false;
                         }
                         
                       case 3:
                           System.out.println(Auxiliar.Avanzar(Auxiliar.getGasolina()));  
                       
                       case 4:
                           System.out.println("A que direccion quiere girar: Izquierda/Derecha?");
                           Giro = input.nextLine();
                           
                            System.out.println(Auxiliar.Izquierda_Derecha(Giro, Auxiliar.getGasolina()));
                       
                       case 5:
                          if(Activo == true){
                              System.out.println("Primero apague el vehiculo"); 
                          }
                          else{
                              Vehieje = false;
                          }
                   }
                }
                ListaVehi.set(Opcion, Auxiliar);
             }
             else{
               Ciclo = false;  
             }
        }
        
    }
    
}
