/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polimorfismo;

/**
 *
 * @author Arthusr56
 */
public class Automovil extends Transporte implements IAvanzar{
    
   private String Marca;
   private String Modelo;
   private String Precio;
   private String Color;
   private int gasolina;

   public boolean Izquierda_Derecha(String Vuelta,int gasolina){
        System.out.println("****" + this.Marca + "****");
        System.out.println("Modelo: " + this.Modelo);
        System.out.println("Color:" + this.Color);
        System.out.println("Precio: " + this.Precio);       
       
    boolean Valido = true; 
       
       if(gasolina > 0){
         if("Izquierda".equals(Vuelta)){
             System.out.println("El vehiculo giro a la izquierda");  
         }
         else{
             System.out.println("El vehiculo giro a la derecha");
         }
       }
       else{
        Valido = false;   
       }
       
    return Valido;
   }
   
    @Override
    public String Encender(int gasolina) {
        System.out.println("****" + this.Marca + "****");
        System.out.println("Modelo: " + this.Modelo);
        System.out.println("Color:" + this.Color);
        System.out.println("Precio: " + this.Precio);        
        
      if(gasolina > 0){
        this.gasolina -= 1;
          return "Vehiculo encendiendo";
      }  
      else return "No hay gasolina, el vehiculo no puede encender";
    }
    
    @Override
    public String Apagar(){
      return "Vehiculo apagado";  
    }

    @Override
    public String Avanzar(int gasolina) {
        System.out.println("****" + this.Marca + "****");
        System.out.println("Modelo: " + this.Modelo);
        System.out.println("Color:" + this.Color);
        System.out.println("Precio: " + this.Precio);
        
      if(gasolina > 0){
        this.gasolina -= 1; 
        return "Vehiculo avanzando";
      }
      else return "No hay gasolina, el vehiculo no puede avanzar";
    }

    /**
     * @return the Marca
     */
    public String getMarca() {
        return Marca;
    }

    /**
     * @param Marca the Marca to set
     */
    public void setMarca(String Marca) {
        this.Marca = Marca;
    }

    /**
     * @return the Modelo
     */
    public String getModelo() {
        return Modelo;
    }

    /**
     * @param Modelo the Modelo to set
     */
    public void setModelo(String Modelo) {
        this.Modelo = Modelo;
    }

    /**
     * @return the Precio
     */
    public String getPrecio() {
        return Precio;
    }

    /**
     * @param Precio the Precio to set
     */
    public void setPrecio(String Precio) {
        this.Precio = Precio;
    }

    /**
     * @return the Color
     */
    public String getColor() {
        return Color;
    }

    /**
     * @param Color the Color to set
     */
    public void setColor(String Color) {
        this.Color = Color;
    }

    /**
     * @return the gasolina
     */
    public int getGasolina() {
        return gasolina;
    }

    /**
     * @param gasolina the gasolina to set
     */
    public void setGasolina(int gasolina) {
        this.gasolina = gasolina;
    }
   
}
