/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package funciones.num.pkg3;

/**
 *
 * @author Arthusr56
 */
import java.util.Scanner;

public class FuncionesNum3 {

    /**
     * @param args the command line arguments
     */
    static int cuenta(int N, int Mod, int Lista[]){
     int Ans = 0,Dif;
      for(int i = 0 ; i < N ; i++){
        Dif = Lista[i]-N;
         if(Dif % Mod == 0)Ans += 1;
      }
     
     return Ans;
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        
        int X,Aux;
         X = input.nextInt();
         
        int[] arreglo = new int[X];
        
         for(int i = 0 ; i < X ; i++)
            arreglo[i] = input.nextInt();
         
        int Mod = 1,Res; 
         
        Aux = X;
         while(Aux > 0){
          Aux /= 10;
          Mod *= 10;
         }
         
         Res = cuenta(X,Mod,arreglo);
         System.out.println(Res);
    }
    
}
