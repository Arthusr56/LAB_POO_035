/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package funciones.num.pkg2;

/**
 *
 * @author Arthusr56
 */
import java.util.Scanner;

public class FuncionesNum2 {

    /**
     * @param args the command line arguments
     */
    static int suma(int[] Lista,int N){
     int Sum = 0;
      for(int i = 0; i < N ; i++)
        Sum += Lista[i];  
      
     return Sum;
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        
        int N,Res;
         N = input.nextInt();
         
         int[] arreglo = new int[N];
          for(int i = 0 ; i < N ; i++)
              arreglo[i] = input.nextInt();
         
         Res = suma(arreglo,N); 
         System.out.println(Res);
    }
    
}
