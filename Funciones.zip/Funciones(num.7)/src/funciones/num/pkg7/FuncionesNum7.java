/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package funciones.num.pkg7;

/**
 *
 * @author Arthusr56
 */
import java.util.Scanner;

public class FuncionesNum7 {

    /**
     * @param args the command line arguments
     */
    static void prec(int valor[], String repres[]){
      valor[12]=1000;
      repres[12]="M";
      valor[11]=900;
      repres[11]="CM";
      valor[10]=500;
      repres[10]="D";
      valor[9]=400;
      repres[9]="CD";      
      valor[8]=100;
      repres[8]="C";
      valor[7]=90;
      repres[7]="XC";
      valor[6]=50;
      repres[6]="L";
      valor[5]=40;
      repres[5]="XL";
      valor[4]=10;
      repres[4]="X";
      valor[3]=9;
      repres[3]="IX";
      valor[2]=5;
      repres[2]="V";
      valor[1]=4;
      repres[1]="IV";
      valor[0]=1;
      repres[0]="I";      
    }
    
    static String converoman(int numero,int valor[], String repres[]){
     String Ans = "";
     int i,Cont;
      for(i = 12 ; i >= 0 ; i--){
        Cont = 0;
          while(numero >= valor[i] && Cont < 3){
           Cont += 1;
           Ans = Ans + repres[i];
            numero -= valor[i];
          }  
      }
      
     return Ans;
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        
        int N;
         N = input.nextInt();
         
        int valor[] = new int[13]; 
        String repres[] = new String[13]; 
        prec(valor,repres);
        
        String Res;
        
        Res = converoman(N,valor,repres);
         System.out.println(Res);
    }
    
}
