/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package funciones.num.pkg4.pkg6;

/**
 *
 * @author Arthusr56
 */
import java.util.Scanner;

public class FuncionesNum46 {

    /**
     * @param args the command line arguments
     */
    static void usaelmientras(){
      int i = 1;
       while(i <= 100){
           System.out.println(i + " ");  
           i += 1;
       }
    }
    
    static void usaeldo(){
      int i = 0;
      do{
          i += 1;
          System.out.println(i + " ");   
      }
      while(i <= 100);
    }
    
    static void usaelfor(){
     int i = 1;
      for(i = 1 ; i <= 100 ; i++){
          System.out.println(i + " ");  
      }
       
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        
      usaelmientras();
        System.out.println("\n\n");
      usaeldo();
        System.out.println("\n\n");
      usaelfor();
    }
    
}
