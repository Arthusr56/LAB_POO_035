/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package funciones.num.pkg1;

/**
 *
 * @author Arthusr56
 */
import java.util.Scanner;

public class FuncionesNum1 {

    /**
     * @param args the command line arguments
     */
    static String conversion(int numero){
      String N;
        N = String.valueOf(numero);
      return N;
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        
        String Cadena;
        int Num;
         Num = input.nextInt();
         
         Cadena = conversion(Num);
         System.out.println(Cadena);
    }
    
}
