/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica5;

/**
 *
 * @author Arthusr56
 */
import java.util.Scanner;

public class Practica5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        Telefono tel[] = new Telefono[5];
        Contacto con[][] = new Contacto[5][5];
        
        String mar;
        String mode;
        String nom;
        int Tel;
        String Corr;
        
         for(int i = 0 ; i < 5 ; i++ ){
           tel[i] = new Telefono();
             System.out.println("Ingrese la marca y precio del telefono");
             
              mar = input.nextLine();
              mode = input.nextLine();
              
              tel[i].setMarca(mar);
              tel[i].setModelo(mode);
           
            for(int j = 0 ; j < 5 ; j++ ){
               con[i][j] = new Contacto();
                System.out.println("Ingrese el nombre, telefono y correo del contacto");
                
                nom = input.nextLine();
                Tel = input.nextInt();
                Corr = input.nextLine();
                
                 con[i][j].setNombre(nom);
                 con[i][j].setTelefono(Tel);
                 con[i][j].setEmail(Corr);
            }
         }
         
       String Acc = "a",Opc;
       boolean Fin = false;
       int Ind,Aux;
       
       while(!Fin){
           System.out.println("Que celular quiere usar? (ingrese la marca y el modelo)");
            mar = input.nextLine();
            mode = input.nextLine();
           

            for( Ind = 0 ; Ind < 5 ; Ind++ ){
              if(mar == tel[Ind].getMarca() && mode == tel[Ind].getModelo())
                   break;  
            }
            tel[Ind].encender();
            
           System.out.println("A que contacto quiere llamar?");
            for(int i = 0 ; i < 5 ; i++ ){
                System.out.println(con[Ind][i].getTelefono());  
            }
           
           Tel = input.nextInt();
           
            for( Aux = 0 ; Aux < 5 ; Aux++ ){
              if(con[Ind][Aux].getTelefono() == Tel)
                  break;
            }
           
           System.out.println("Ingrese contraseña: ");
           nom = input.nextLine();

            if(tel[Ind].setpassword(nom) == true){
                System.out.println(tel[Ind].getMarca() + " " + tel[Ind].getModelo());
                System.out.println("Conectando..... conexion exitosa");
                System.out.println(tel[Ind].Iniciarllamada(con[Ind][Aux].getTelefono()));
                System.out.println(tel[Ind].Iniciarllamada(con[Ind][Aux]));
                System.out.println(tel[Ind].finalizarllamada());
            }
            else{
                System.out.println("Falla al conectarse... no se pudo llamar al contacto");  
            }
            
          tel[Ind].apagar();
       }
    }
    
}
