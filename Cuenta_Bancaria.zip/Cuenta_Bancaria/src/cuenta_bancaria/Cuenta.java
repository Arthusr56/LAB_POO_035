/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cuenta_bancaria;

/**
 *
 * @author Arthusr56
 */
public class Cuenta {
    
  private String Nombre;
  private String NumeroCuenta;
  private double TipoInteres;
  private double Saldo;

   public Cuenta(){}
   
   public Cuenta(String Nombre, String NumeroCuenta, double TipoInteres, double Saldo){
     this.Nombre = Nombre;
     this.NumeroCuenta = NumeroCuenta;
     this.TipoInteres = TipoInteres;
     this.Saldo = Saldo;
   }
   
   public Cuenta(final Cuenta cp){
     Nombre = cp.Nombre;
     NumeroCuenta = cp.NumeroCuenta;
     TipoInteres = cp.TipoInteres;
     Saldo = cp.Saldo;
   }

    /**
     * @return the Nombre
     */
    public String getNombre() {
        return Nombre;
    }

    /**
     * @param Nombre the Nombre to set
     */
    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    /**
     * @return the NumeroCuenta
     */
    public String getNumeroCuenta() {
        return NumeroCuenta;
    }

    /**
     * @param NumeroCuenta the NumeroCuenta to set
     */
    public void setNumeroCuenta(String NumeroCuenta) {
        this.NumeroCuenta = NumeroCuenta;
    }

    /**
     * @return the TipoInteres
     */
    public double getTipoInteres() {
        return TipoInteres;
    }

    /**
     * @param TipoInteres the TipoInteres to set
     */
    public void setTipoInteres(double TipoInteres) {
        this.TipoInteres = TipoInteres;
    }

    /**
     * @return the Saldo
     */
    public double getSaldo() {
        return Saldo;
    }

    /**
     * @param Saldo the Saldo to set
     */
    public void setSaldo(double Saldo) {
        this.Saldo = Saldo;
    }

   public boolean Ingreso(int Aumento){
     
     boolean Valido = true;
     
      if(Aumento < 0){
        Valido = false;  
      }
      else{
        Saldo = Saldo + Aumento;  
      }
      
     return Valido; 
   }
   
   public boolean Reintegro(int Exporta){
     
      boolean Valido = true;
      
       if(Exporta < 0){
         Valido = false;  
       }
       else{
         if(Exporta > Saldo){
           Valido = false;  
         }  
         else{
            Saldo = Saldo - Exporta; 
         }
       }
      return Valido;
   }
   
   public boolean Transferencia(Cuenta Destino, int Importe){
     
       boolean Valido = true;
       
        if(Importe < 0 || Saldo < Importe){
           Valido = false;
        }
        else{
          Reintegro(Importe);
          Destino.Ingreso(Importe);
        }
      return Valido;  
   }
   
}
