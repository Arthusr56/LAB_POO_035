/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package animales;

/**
 *
 * @author Arthusr56
 */
import java.util.Scanner;

public class Animales {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
     Scanner input = new Scanner(System.in);
     int Action = 1;
     
     Perro Anip[] = new Perro[20];
     int indP = 1;
     Gato Anig[] = new Gato[20];
     int indG = 1;
     Ave Ania[] = new Ave[20];
     int indA = 1;
     
     String consumidor;
     String raza;
     int Comando;
     int i;
     
      while(Action == 1){
          System.out.println("Que comando quieres utilizar?\n");
          System.out.println("1.- Agregar perro");
          System.out.println("2.- Agregar gato");
          System.out.println("3.- Agregar ave");
          System.out.println("4.- Comer");
          System.out.println("5.- Ladrar");
          System.out.println("6.- Caminar");
          System.out.println("7.- Correr");
          System.out.println("8.- Maullido");
          System.out.println("9.- Brincar");
          System.out.println("10.- Volar");
          System.out.println("11.- Cantar");
          System.out.println("12.- Salir");
        Comando = input.nextInt();
        
         switch(Comando){
             case 1:
              consumidor = input.nextLine();
              raza = input.nextLine();
               Anip[indP] = new Perro(consumidor,raza);
               indP += 1;
             case 2:
              consumidor = input.nextLine();
              raza = input.nextLine();
               Anig[indG] = new Gato(consumidor,raza);
             case 3:
              consumidor = input.nextLine();
              raza = input.nextLine();
               Ania[indA] = new Ave(consumidor,raza);
             case 4:
              for(i = 1; i < indP; i++){
                  System.out.println("El perro " + Anip[i].getConsumidor() + " de raza " + Anip[i].getRaza() + "se pone a comer, se ve satisfecho");
              }
              for(i = 1; i < indG; i++){
                  System.out.println("El gato " + Anig[i].getConsumidor() + " de raza " + Anig[i].getRaza() + "se pone a comer, se ve satisfecho");
              }   
              for(i = 1; i < indA; i++){
                  System.out.println("El ave " + Ania[i].getConsumidor() + " de raza " + Ania[i].getRaza() + "se pone a comer, se ve satisfecho");                  
              }
                 
             case 5:
              for(i = 1; i < indP; i++){
                  System.out.println("El perro " + Anip[i].getConsumidor() + " de raza " + Anip[i].getRaza() + "ve al vecino y le comienza a ladrar");   
              }   
                 
             case 6:
              for(i = 1; i < indP; i++){
                  System.out.println("El perro " + Anip[i].getConsumidor() + " de raza " + Anip[i].getRaza() + "decide dar una vuelta por la vecindad");
              }   
                 
             case 7:
              for(i = 1; i < indP; i++){
               if(Anip[i].getRaza() == "Pastor" || Anip[i].getRaza() == "Chihuahua")
                 System.out.println("El perro " + Anip[i].getConsumidor() + " de raza " + Anip[i].getRaza() + "comienza a correr por el carro que va pasando");  
              }   
             case 8:
              for(i = 1; i < indG; i++){
                 System.out.println("El gato " + Anig[i].getConsumidor() + " de raza " + Anig[i].getRaza() + "maulla para atraer la atencion de sus dueños"); 
              }   
             case 9:
              for(i = 1; i < indG; i++){
                 System.out.println("El gato " + Anig[i].getConsumidor() + " de raza " + Anig[i].getRaza() + "brinca del susto"); 
              }   
             case 10:
              for(i = 1; i < indA; i++){
                 System.out.println("El ave " + Ania[i].getConsumidor() + " de raza " + Ania[i].getRaza() + "expande sus alas y se va volando"); 
              }   
             case 11:
              for(i = 1; i < indA; i++){
                 System.out.println("El cotorro " + Ania[i].getConsumidor() + "comienza a cantar, atrae la atencion de varias personas"); 
              }   
             case 12:
               Action = 0;
         }
      }
     
    }
    
}
