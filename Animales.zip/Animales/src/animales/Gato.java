/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package animales;

/**
 *
 * @author Arthusr56
 */
public class Gato {
    
  private String consumidor;
  private String raza;

    public Gato(String consumidor,String raza){
      
     this.consumidor = consumidor;
     this.raza = raza;
    }
    /**
     * @return the consumidor
     */
    public String getConsumidor() {
        return consumidor;
    }

    /**
     * @param consumidor the consumidor to set
     */
    public void setConsumidor(String consumidor) {
        this.consumidor = consumidor;
    }

    /**
     * @return the raza
     */
    public String getRaza() {
        return raza;
    }

    /**
     * @param raza the raza to set
     */
    public void setRaza(String raza) {
        this.raza = raza;
    }
}
