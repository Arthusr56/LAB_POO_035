/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica3_diel;

/**
 *
 * @author Arthusr56
 */
public class Calculadora extends Dispositivo_Electronico implements IOperaciones_Aritmeticas{

    @Override
    public String encender() {
        return "Encendiendo Calculadora";
    }

    @Override
    public String apagar() {
       return "Apagando Calculadora";
    }

    @Override
    public int Suma(int a, int b) {
        return a+b;
    }

    @Override
    public int Resta(int a, int b) {
        return a-b;
    }

    @Override
    public int Multiplica(int a, int b) {
        return a*b;
    }

    @Override
    public int Divide(int a, int b) {
        return a/b;
    }
    
}
