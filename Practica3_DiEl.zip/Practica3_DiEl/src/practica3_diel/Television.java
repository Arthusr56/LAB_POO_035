/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica3_diel;

/**
 *
 * @author Arthusr56
 */
public class Television extends Dispositivo_Electronico implements IFunciones {

    @Override
    public String encender() {
        return "Encendiendo television";
    }

    @Override
    public String apagar() {
       return "Apagando television";
    }

    @Override
    public String cambioCanal() {
        return "Cambiando canal";
    }

    @Override
    public String Volumen() {
        return "Ajustando volumen";
    }
    
}
