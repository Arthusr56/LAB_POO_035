/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica3_diel;

import java.util.Scanner;
/**
 *
 * @author Arthusr56
 */
public class Practica3_DiEl {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Calculadora canon = new Calculadora();
        Television lg = new Television();
        Radio sunstech = new Radio();
        Scanner input = new Scanner(System.in);
        
      String marca;
      String modelo;
      String color;
      String Acc;
      int a,b;
      
        System.out.println("Escriba la marca, el modelo y el color del dispositivo en lineas separadas");
        marca = input.nextLine();
        modelo = input.nextLine();
        color = input.nextLine();      
      
        System.out.println("Escriba la letra del inciso que corresponda al dispositivo que quiera utilizar:");
        System.out.println("a) Television");
        System.out.println("b) Radio");
        System.out.println("c) Calculadora");
        
        Acc = input.nextLine();
        
        System.out.println("Marca: " + marca);
        System.out.println("Modelo: " + modelo);
        System.out.println("Color: " + color);
        
         switch (Acc) {
            case "a":///             Es una television
                System.out.println("--Television--\n\n");
                while(Acc != "e"){
                    System.out.println("Que quiere hacer?");
                    System.out.println("a) Encender");
                    System.out.println("b) Apagar");
                    System.out.println("c) Cambiar de canal");
                    System.out.println("d) Ajustar volumen");
                    System.out.println("e) Salir");
                    Acc = input.nextLine();
                    
                    switch(Acc){
                        case "a":
                            System.out.println("\n" + lg.encender() + "\n");
                            
                        case "b":
                            System.out.println("\n" + lg.apagar() + "\n");
                            
                        case "c":
                            System.out.println("\n" + lg.cambioCanal() + "\n");
                            
                        case "d":
                            System.out.println("\n" + lg.Volumen() + "\n");
                    }
                }   break;
            case "b":///                   Es una radio
                System.out.println("--Radio--\n\n");
                while(Acc != "e"){
                    System.out.println("Que quiere hacer?");
                    System.out.println("a) Encender");
                    System.out.println("b) Apagar");
                    System.out.println("c) Cambiar de canal");
                    System.out.println("d) Ajustar volumen");
                    System.out.println("e) Salir");
                    Acc = input.nextLine();
                    
                    switch(Acc){
                        case "a":
                            System.out.println("\n" + sunstech.encender() + "\n");
                            
                        case "b":
                            System.out.println("\n" + sunstech.apagar() + "\n");
                            
                        case "c":
                            System.out.println("\n" + sunstech.cambioCanal() + "\n");
                            
                        case "d":
                            System.out.println("\n" + sunstech.Volumen() + "\n");
                    }
                }   break;
            case "c":///               Es una calculadora
                System.out.println("--Calculadora--\n\n");
                while(Acc != "g"){
                    System.out.println("Que quiere hacer?");
                    System.out.println("a) Encender");
                    System.out.println("b) Apagar");
                    System.out.println("c) Suma");
                    System.out.println("d) Resta");
                    System.out.println("e) Multiplica");
                    System.out.println("f) Divide");
                    System.out.println("g) Salir");
                    Acc = input.nextLine();
                    
                    switch(Acc){
                        case "a":
                            System.out.println("\n" + canon.encender() + "\n");
                            
                        case "b":
                            System.out.println("\n" + canon.apagar() + "\n");
                            
                        case "c":
                            System.out.println("Introduzca el valor de los enteros");
                            a = input.nextInt();
                            b = input.nextInt();
                            System.out.println("\n" + canon.Suma(a, b) + "\n");
                            
                        case "d":
                            System.out.println("Introduzca el valor de los enteros");
                            a = input.nextInt();
                            b = input.nextInt();
                            System.out.println("\n" + canon.Resta(a, b) + "\n");
                            
                        case "e":
                            System.out.println("Introduzca el valor de los enteros");
                            a = input.nextInt();
                            b = input.nextInt();
                            System.out.println("\n" + canon.Multiplica(a, b) + "\n");
                            
                        case "f":
                            System.out.println("Introduzca el valor de los enteros");
                            a = input.nextInt();
                            b = input.nextInt();
                            System.out.println("\n" + canon.Divide(a, b) + "\n");
                    }
                }
        }
    }
    
}
