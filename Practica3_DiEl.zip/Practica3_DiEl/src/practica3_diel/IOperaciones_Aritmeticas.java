/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica3_diel;

/**
 *
 * @author Arthusr56
 */
public interface IOperaciones_Aritmeticas {
   
  public int Suma(int a, int b);
  public int Resta(int a, int b);
  public int Multiplica(int a, int b);
  public int Divide(int a, int b);
  
}
