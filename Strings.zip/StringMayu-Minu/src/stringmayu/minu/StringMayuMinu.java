/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stringmayu.minu;

/**
 *
 * @author Arthusr56
 */
import java.util.Scanner;

public class StringMayuMinu {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        
        String Cadena,Res = "";
         
         System.out.println("Ingrese una cadena:");
         Cadena = input.nextLine();
         
         char Nuevo;
         int conv;
         
        for(int i = 0 ; i < Cadena.length() ; i++){
          Nuevo = Cadena.charAt(i);
            //System.out.print(Nuevo + " -> ");
          conv = Nuevo;
          
           if(65 <= conv && conv <= 90)Nuevo += 32;
           else Nuevo -= 32;
            //System.out.println(Nuevo);
           
           Res = Res + Nuevo;
        }
        
        System.out.println("Intercambiando minusculas y mayusculas, la nueva cadena queda de la siguiente manera: " + Res); 
    }
    
}
