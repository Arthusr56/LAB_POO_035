/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stringsubcadena;

/**
 *
 * @author Arthusr56
 */
import java.util.Scanner;

public class StringSubcadena {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        
        String CadA,CadB;
         System.out.println("Ingrese una cadena: ");
         CadA = input.nextLine();
         System.out.println("Ingrese otra cadena: ");
         CadB = input.nextLine();
         
         boolean ValA = CadA.contains(CadB);
         boolean ValB = CadB.contains(CadA);
         
         if(ValA == true && ValB == true){
             System.out.println("Ambos son subcadena del otro; por ende, son la misma cadena");
         }
         else if(ValA == true){
             System.out.println("La primera cadena contiene a la segunda cadena");
         }
         else if(ValB == true){
             System.out.println("La segunda cadena contiene a la primera cadena");
         }
         else{
             System.out.println("Ninguna cadena contiene a la otra");
         }
    }
    
}
