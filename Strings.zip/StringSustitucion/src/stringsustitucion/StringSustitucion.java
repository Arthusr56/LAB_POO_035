/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stringsustitucion;

/**
 *
 * @author Arthusr56
 */
import java.util.Scanner;

public class StringSustitucion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        
        String Cadena , Res;
        char CaracterActual,NuevoCaracter;
        
         System.out.println("Ingrese una cadena");
         Cadena = input.nextLine();
         System.out.println("Ingrese el caracter a reemplazar de la cadena");
         CaracterActual = input.nextLine().charAt(0);
         System.out.println("Ingrese el caracter que reemplazara el caracter ingresado");
         NuevoCaracter = input.nextLine().charAt(0);
         
         Res = Cadena.replace(CaracterActual, NuevoCaracter);
         
          System.out.println("La nueva cadena es la siguiente: " + Res);
    }
    
}
