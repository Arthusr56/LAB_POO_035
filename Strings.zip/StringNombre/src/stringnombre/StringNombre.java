/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stringnombre;

/**
 *
 * @author Arthusr56
 */
import java.util.Scanner;

public class StringNombre {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        
        String Nombre;
         System.out.println("Ingrese su nombre seguido de su apellido");
         Nombre = input.nextLine();
         
        int i = 0;
         System.out.println("Inicial del nombre: " + Nombre.charAt(0));
         while(Nombre.charAt(i) != ' ')i += 1;
         i += 1;
         
         System.out.println("Inicial del apellido: " + Nombre.charAt(i));
         
    }
    
}
