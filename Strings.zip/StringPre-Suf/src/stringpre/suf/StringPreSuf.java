/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stringpre.suf;

/**
 *
 * @author Arthusr56
 */
import java.util.Scanner;

public class StringPreSuf {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        
        String Cadena;
        String Seg;
        
         System.out.println("Ingrese una cadena:");
         Cadena = input.nextLine();
         System.out.println("Ingrese una segunda cadena:");
         Seg = input.nextLine();
         
         if(Cadena.startsWith(Seg)){
             System.out.println("La segunda cadena es un prefijo de la primera cadena");
         }
         else if(Cadena.endsWith(Seg)){
             System.out.println("La segunda cadena es un sufijo de la primera cadena");
         }
         else{
             System.out.println("La segunda cadena no es prefijo ni sufijo de la primera cadena");
         }
    }
    
}
