/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stringpalindromo;

/**
 *
 * @author Arthusr56
 */
import java.util.Scanner;

public class StringPalindromo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        
        String Cadena,Inversa = "";
        char Caracter;
        
         System.out.println("Ingrese una cadena: ");
         Cadena = input.nextLine();
         
          for(int i = Cadena.length() - 1 ; i >= 0 ; i--){
            Caracter = Cadena.charAt(i);
             Inversa = Inversa + Caracter;
          }
          //System.out.println(Inversa);
          boolean Iguales = true;
         
          for(int i = 0 ; i < Cadena.length() ; i++){
             if(Cadena.charAt(i) != Inversa.charAt(i))Iguales = false; 
          }
          
          if(Iguales == true){
              System.out.println("La cadena es palindroma"); 
          }
          else{
              System.out.println("La cadena no es palindroma");
          }
    }
    
}
