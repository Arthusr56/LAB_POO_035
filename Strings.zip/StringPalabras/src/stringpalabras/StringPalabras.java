/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stringpalabras;

/**
 *
 * @author Arthusr56
 */
import java.util.Scanner;

public class StringPalabras {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        
        String Oracion;
        int Palabras = 1,i;
        
         System.out.println("Ingrese una palabra u oracion");
         Oracion = input.nextLine();
         
         for(i = 0 ; i < Oracion.length() ; i++){
            if(Oracion.charAt(i) == ' ')
                 Palabras += 1;
         }
         
         if(Oracion.charAt(i - 1) == ' ')
              Palabras -= 1;
         
         System.out.println("Hay un total de " + Palabras + " palabras en la oracion");
        
    }
    
}
