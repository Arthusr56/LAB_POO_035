/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stringinversa;

/**
 *
 * @author Arthusr56
 */
import java.util.Scanner;

public class StringInversa {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        
        String Cadena;
         System.out.println("Ingrese una cadena");
         Cadena = input.nextLine();
         
         System.out.println("La cadena invertida es la siguiente:");
         for(int i = Cadena.length() - 1 ; i >= 0 ; i--){
             System.out.print(Cadena.charAt(i));  
         }
         System.out.println("");
    }
    
}
