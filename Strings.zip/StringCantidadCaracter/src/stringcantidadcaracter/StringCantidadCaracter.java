/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stringcantidadcaracter;

/**
 *
 * @author Arthusr56
 */
import java.util.Scanner;

public class StringCantidadCaracter {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        
        String Cadena;
        char Caracter,Aux; 
        int Cantidad = 0;
         
         System.out.println("Ingrese una cadena:");
         Cadena = input.nextLine();
         System.out.println("Ingrese un caracter:");
         Caracter = input.next().charAt(0);
         
         for(int i = 0 ; i < Cadena.length() ; i++){
            Aux = Cadena.charAt(i);
             if(Aux == Caracter)
                   Cantidad += 1;
         }
     
         System.out.println("El caracter " + Caracter + " aparece " + Cantidad + " veces");
    }
    
}
