/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stringguiones;

/**
 *
 * @author Arthusr56
 */
import java.util.Scanner;

public class StringGuiones {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        
         String Cadena;
         char Res;
         
          System.out.println("Ingrese una cadena:\n");
          Cadena = input.nextLine();
          
          for(int i = 0 ; i < Cadena.length() ; i++){
              Res = Cadena.charAt(i);
              if(i == Cadena.length() - 1) System.out.println(Res);
              else  System.out.print(Res + "-");
          }
    }
    
}
